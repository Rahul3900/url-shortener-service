package com.backend.url_shortener_service.Repository;

import com.backend.url_shortener_service.Entity.UrlEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UrlRepository extends JpaRepository<UrlEntity,Long> {

    Optional<UrlEntity> findByShortCode(String shortCode);
    boolean existsByShortCode(String customAlias);
}
