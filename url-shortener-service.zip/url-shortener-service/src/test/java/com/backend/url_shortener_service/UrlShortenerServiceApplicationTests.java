package com.backend.url_shortener_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UrlShortenerServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
